﻿using System;
using System.Collections.Generic;

#nullable disable

namespace APICOMP2001
{
    public partial class Session
    {
        public int SessionId { get; set; }
        public int SessionUserId { get; set; }
        public DateTime SessionDateTime { get; set; }

        public virtual User SessionUser { get; set; }
    }
}
