﻿using System;
using System.Collections.Generic;

#nullable disable

namespace APICOMP2001
{
    public partial class Password
    {
        public int PassId { get; set; }
        public int PassUserId { get; set; }
        public string PassPassword { get; set; }
        public DateTime PassDateChange { get; set; }

        public virtual User PassUser { get; set; }
    }
}
