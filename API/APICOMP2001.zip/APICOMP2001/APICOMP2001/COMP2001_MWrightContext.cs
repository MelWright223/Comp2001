﻿using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace APICOMP2001
{
    public partial class COMP2001_MWrightContext : DbContext
    {
        public COMP2001_MWrightContext()
        {
        }

        public COMP2001_MWrightContext(DbContextOptions<COMP2001_MWrightContext> options)
            : base(options)
        {
        }

     
        public virtual DbSet<Password> Passwords { get; set; }
        public virtual DbSet<Session> Sessions { get; set; }
        public virtual DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=socem1.uopnet.plymouth.ac.uk;Database=COMP2001_MWright;User Id=MWright;Password=KdnY776*");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Password>(entity =>
            {
                entity.HasKey(e => e.PassId)
                    .HasName("pk_passId");

                entity.Property(e => e.PassId).HasColumnName("passId");

                entity.Property(e => e.PassDateChange)
                    .HasColumnType("datetime")
                    .HasColumnName("passDateChange");

                entity.Property(e => e.PassPassword)
                    .IsRequired()
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("passPassword");

                entity.Property(e => e.PassUserId).HasColumnName("passUserId");

                entity.HasOne(d => d.PassUser)
                    .WithMany(p => p.Passwords)
                    .HasForeignKey(d => d.PassUserId)
                    .HasConstraintName("fk_userId");
            });

            modelBuilder.Entity<Session>(entity =>
            {
                entity.Property(e => e.SessionId).HasColumnName("sessionId");

                entity.Property(e => e.SessionDateTime)
                    .HasColumnType("datetime")
                    .HasColumnName("sessionDateTime");

                entity.Property(e => e.SessionUserId).HasColumnName("sessionUserId");

                entity.HasOne(d => d.SessionUser)
                    .WithMany(p => p.Sessions)
                    .HasForeignKey(d => d.SessionUserId)
                    .HasConstraintName("fk_sessUserId");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.UserEmail)
                    .IsRequired()
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("userEmail");

                entity.Property(e => e.UserFirstName)
                    .IsRequired()
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("userFirstName");

                entity.Property(e => e.UserLastName)
                    .IsRequired()
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("userLastName");

                entity.Property(e => e.UserPassword)
                    .IsRequired()
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("userPassword");

                entity.Property(e => e.UserUserName)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("userUserName");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
        public string addUser(addUser user, int response)
        {
            COMP2001_MWrightContext regContext = new COMP2001_MWrightContext();
          var rows = regContext.Database.ExecuteSqlRaw("EXEC addUser @userId, @userFirstName, @userLastName, @userEmail, @userPassword, @userUserName",
                  new SqlParameter("@userId", user.userId.ToString()),
                  new SqlParameter("@userFirstName", user.userFirstName.ToString()),
                  new SqlParameter("@userLastName", user.userLastName.ToString()),
                  new SqlParameter("@userEmail", user.userEmail.ToString()),
                  new SqlParameter("@userPassword", user.userPassword.ToString()),
                  new SqlParameter("@userUserName", user.userUserName.ToString()));

            return rows.ToString();





        }
    }
    
}
