﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APICOMP2001
{
    public class DeleteUser
    {
        public int userId { get; set; }
    }
}
