﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APICOMP2001
{
    public class validateUser
    {
        public string userUserName { get; set; }
        public string userPassword { get; set; }

    }
}
