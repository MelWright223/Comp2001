﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APICOMP2001
{
    public class addUser
    {
        public int userId { get; set; }
        public string userFirstName {get; set; }
        public string userLastName {get; set; }
        public string userEmail {get; set; }
        public string userPassword {get; set; }
        public string userUserName {get; set; }

    }
}
